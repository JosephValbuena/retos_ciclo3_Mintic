package com.sergioa.backendMinticReto3.repository;

import com.sergioa.backendMinticReto3.crud.repository.MessageRepositoryCrud;
import com.sergioa.backendMinticReto3.model.Message;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */

@Repository
public class MessageRepository {
    
    @Autowired
    MessageRepositoryCrud messageRepositoryCrud;
    
    public List<Message> getAll(){
        return (List<Message>) messageRepositoryCrud.findAll();
    }
    
    public Optional<Message> getMessage(int id){
        return messageRepositoryCrud.findById(id);
    }
    
    public Message save(Message message){
        return messageRepositoryCrud.save(message);
    }
}
