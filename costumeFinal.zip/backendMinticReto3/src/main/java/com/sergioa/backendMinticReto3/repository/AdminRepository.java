package com.sergioa.backendMinticReto3.repository;

import com.sergioa.backendMinticReto3.crud.repository.AdminRepositoryCrud;
import com.sergioa.backendMinticReto3.model.Admin;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */

@Repository
public class AdminRepository {
    
    @Autowired
    private AdminRepositoryCrud adminRepositoryCrud;
    
    
     /**
     * Accede al método de findAll()
     * @return Retorna un listado administradores
     */
    public List<Admin>getAll(){
        return (List<Admin>) adminRepositoryCrud.findAll();
    }
    
    /**
     * Accede al método de save()
     * @param id
     * @return Retorna un administrador
     */
    public Optional<Admin> getAdmin(int id){
        return adminRepositoryCrud.findById(id);
    }
    
    /**
     * Accede al método de save()
     * @param admin
     * @return Retorna el administrador creado
     */
    public Admin save(Admin admin){
        return adminRepositoryCrud.save(admin);
    }
}
