package com.sergioa.backendMinticReto3.repository;

import com.sergioa.backendMinticReto3.crud.repository.CategoryRepositoryCrud;
import com.sergioa.backendMinticReto3.model.Category;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */

@Repository
public class CategoryRepository {
    
    @Autowired
    CategoryRepositoryCrud categoryRepositoryCrud;
    
    public List<Category> getAll(){
        return (List<Category>) categoryRepositoryCrud.findAll();
    }
    
    public Optional<Category> getCategory(int id){
        return categoryRepositoryCrud.findById(id);
    }
    
    public Category save(Category category){
        return categoryRepositoryCrud.save(category);
    }
}
