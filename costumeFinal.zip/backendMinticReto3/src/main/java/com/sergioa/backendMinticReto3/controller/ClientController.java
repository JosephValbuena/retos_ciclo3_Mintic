package com.sergioa.backendMinticReto3.controller;

import com.sergioa.backendMinticReto3.model.Client;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.sergioa.backendMinticReto3.crud.repository.ClientRepositoryCrud;
import com.sergioa.backendMinticReto3.services.ClientService;

/**
 * @author josva
 */

@RestController
@RequestMapping("/api/Client")
@CrossOrigin
public class ClientController {
    
    
    
    @Autowired
    ClientService clientService;
    
    @GetMapping("/all")
    public List<Client> getAll(){
        List<Client> clientes = (List<Client>) clientService.getAll();
        return clientes;
    }
    
    @PostMapping("/save")
    public Client save(@RequestBody Client client){
        return clientService.save(client);
    }
}
