package com.sergioa.backendMinticReto3.crud.repository;

import com.sergioa.backendMinticReto3.model.Message;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author josva
 */

public interface MessageRepositoryCrud extends CrudRepository<Message, Integer>{
    
}
