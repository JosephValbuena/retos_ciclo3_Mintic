package com.sergioa.backendMinticReto3.repository;

import com.sergioa.backendMinticReto3.crud.repository.ClientRepositoryCrud;
import com.sergioa.backendMinticReto3.model.Client;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */

@Repository
public class ClientRepository {
    
    @Autowired
    ClientRepositoryCrud clientRepositoryCrud;
    
    public List<Client> getAll(){
        return (List<Client>) clientRepositoryCrud.findAll();
    }
    
    public Optional<Client> getClient(int id){
        return clientRepositoryCrud.findById(id);
    }
    
    public Client save(Client client){
        return clientRepositoryCrud.save(client);
    }
    
}
