package com.sergioa.backendMinticReto3.repository;

import com.sergioa.backendMinticReto3.crud.repository.ScoreRepositoryCrud;
import com.sergioa.backendMinticReto3.model.Score;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */

@Repository
public class ScoreRepository {
    @Autowired
    private ScoreRepositoryCrud scoreRepositoryCrud;
    
    public List<Score> getAll(){
        return (List<Score>) scoreRepositoryCrud.findAll();
    }
    
    public Optional<Score> getScore(int id){
        return scoreRepositoryCrud.findById(id);
    }  
  
    public Score save(Score score){
        return scoreRepositoryCrud.save(score);
    }
}
