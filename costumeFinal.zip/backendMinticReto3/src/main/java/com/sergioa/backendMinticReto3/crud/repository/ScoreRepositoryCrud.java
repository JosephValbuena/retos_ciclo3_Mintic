
package com.sergioa.backendMinticReto3.crud.repository;

import com.sergioa.backendMinticReto3.model.Score;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author josva
 */
public interface ScoreRepositoryCrud extends CrudRepository<Score, Integer>{
    
}
