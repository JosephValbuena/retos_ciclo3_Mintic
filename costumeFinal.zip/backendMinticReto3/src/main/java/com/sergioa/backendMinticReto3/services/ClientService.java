package com.sergioa.backendMinticReto3.services;

import com.sergioa.backendMinticReto3.model.Client;
import com.sergioa.backendMinticReto3.repository.ClientRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author josva
 */

@Service
public class ClientService {
    
    @Autowired
    ClientRepository clientRepository;
    
    public List<Client> getAll(){
        return clientRepository.getAll();
    }
    
    public Client save(Client client){
        if(String.valueOf(client.getIdClient()) == null){
            return clientRepository.save(client);
        }else{
            Optional<Client> cliente = clientRepository.getClient(client.getIdClient());
            if(cliente.isEmpty()){
                return clientRepository.save(client);
            }else{
                return client;
            }
        }
    }
    
}
