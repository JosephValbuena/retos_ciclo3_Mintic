package com.sergioa.backendMinticReto3.services;

import com.sergioa.backendMinticReto3.model.Admin;
import org.springframework.stereotype.Service;
import com.sergioa.backendMinticReto3.repository.AdminRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author josva
 */

@Service
public class AdminService {
    
    @Autowired
    private AdminRepository adminRepository;
    
    public List<Admin> getAll(){
        return adminRepository.getAll();
        
    }
    
  
    public Admin save(Admin admin){
        if(String.valueOf(admin.getId()) == null){
            return adminRepository.save(admin);
        }else{
            Optional<Admin> admin1 = adminRepository.getAdmin(admin.getId());
            if(admin1.isEmpty()){
                return adminRepository.save(admin);
            }else{
                return admin;
            }
        }
    }
    //update(Admin admin)
}
