package com.sergioa.backendMinticReto3.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

/**
 * Entidad que apunta hacia la tabla "costume"
 * @author josvalk
 */

@Entity
@Table(name="costume")
public class Costume {
    
    /**
     * Variable para el Id del costume
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    /**
     * Variable para el nombre del costume
     */
    @Column(name="NAME", nullable = false, length = 45)
    private String name;
    
    /**
     * Variable para la marca del costume
     */
    @Column(name="BRAND", nullable = false, length = 45)
    private String brand;
   
    /**
     * Variable para el año del costume
     */
    @Column(name= "YEAR", nullable = false)
    private int year;
    
    /**
     * Variable para la descripción del costume
     */
    @Column(name="DESCRIPTION", nullable = false, columnDefinition = "Text")
    private String description;
    
    /**
     * Relación muchos a uno para obtener los datos de la categoría
     */
    @ManyToOne
    @JoinColumn(name="CATEGORY", nullable = false)
    @JsonIgnoreProperties("costumes")
    public Category category;

    /**
     * Relación muchos a uno para obtener los datos de mensajes 
     */
    @OneToMany(cascade={CascadeType.PERSIST},mappedBy="costume")
    @JsonIgnoreProperties({"costume", "client"})
    public List<Message> messages;
    
    /**
     * Relación uno a muchos para obtener los datos de reservas 
     */
    @OneToMany(cascade={CascadeType.PERSIST}, mappedBy="costume")
    @JsonIgnoreProperties({"id_costume","id_client"})
    public List<Reservation> reservations;

    
    /**
     * 
     * @return id del disfraz
     */
    public int getId() {
        return id;
    }

    /**
     * 
     * @param id 
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * 
     * @return messages del costume
     */
    public List<Message> getMessages() {
        return messages;
    }

    /**
     * 
     * @param messages 
     */
    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }
    
    /**
     * 
     * @return reservations del costume
     */
    public List<Reservation> getReservations() {
        return reservations;
    }

    /**
     * 
     * @param reservations 
     */
    public void setReservations(List<Reservation> reservations) {
        this.reservations = reservations;
    }

    /**
     * 
     * @return brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * 
     * @param brand 
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * 
     * @return year del costume
     */
    public int getYear() {
        return year;
    }

    /**
     * 
     * @param year 
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * 
     * @return category del costume
     */
    public Category getCategory() {
        return category;
    }

    /**
     * 
     * @param category 
     */
    public void setCategory(Category category) {
        this.category = category;
    }

    /**
     * 
     * @return name del costume
     */
    public String getName() {
        return name;
    }

    /**
     * 
     * @param name 
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 
     * @return description del costume
     */
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description 
     */
    public void setDescription(String description) {
        this.description = description;
    } 
}
