package com.sergioa.backendMinticReto3.controller;

import com.sergioa.backendMinticReto3.model.Costume;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.sergioa.backendMinticReto3.services.CostumeService;

/**
 *
 * @author josva
 */
@RestController
@RequestMapping("/api/Costume")
@CrossOrigin
public class CostumeController {
    
    @Autowired
    CostumeService costumeService;
    
    @GetMapping("/all")
    public List<Costume> getAll(){
        return costumeService.getAll();
    }
    
    @PostMapping("/save")
    public Costume save(@RequestBody Costume costume){
        return costumeService.save(costume);
    }
    
}
