package com.sergioa.backendMinticReto3.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import javax.persistence.*;

/**
 *
 * @author josva
 */

@Entity
@Table(name="message")
public class Message implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idMessage")
    private int idMessage;
     
    @Column(name="messageText", nullable = false, length = 250)
    private String messageText;

    @ManyToOne
    @JoinColumn(name="costume",  nullable = false)
    @JsonIgnoreProperties({"messages","reservations"})
    private Costume costume;
    
    
    @ManyToOne
    @JoinColumn(name="client",  nullable = false)
    @JsonIgnoreProperties({"messages","reservations"})
    private Client client;

    public int getIdMessage() {
        return idMessage;
    }

    public void setIdMessage(int idMessage) {
        this.idMessage = idMessage;
    }
 
    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public Costume getCostume() {
        return costume;
    }

    public void setCostume(Costume costume) {
        this.costume = costume;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
    
    
    
    
}
