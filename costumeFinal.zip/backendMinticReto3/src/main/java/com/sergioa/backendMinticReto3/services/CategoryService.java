package com.sergioa.backendMinticReto3.services;

import com.sergioa.backendMinticReto3.model.Category;
import com.sergioa.backendMinticReto3.repository.CategoryRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author josva
 */

@Service
public class CategoryService {
    
    @Autowired
    CategoryRepository categoryRepository;
    
    public List<Category> getAll(){
        return categoryRepository.getAll();
    }
    
    public Category save(Category category){
        
        if(String.valueOf(category.getId()) == null){
            return categoryRepository.save(category);
        }else{
            Optional<Category> categoria = categoryRepository.getCategory(category.getId());
            
            if(categoria.isEmpty()){
                return categoryRepository.save(category);
            }else{
                return category;
            }
        }
    }
}
