package com.costume;

import com.costume.repository.crud.ReservationCrudRepository;
import org.springframework.boot.CommandLineRunner;

/**
 *
 * @author desaextremo
 */
public class AdmCostumeRunner implements CommandLineRunner {
    
    private ReservationCrudRepository reservationCrudRepository;
    
    @Override
    public void run(String... args) throws Exception {
        
    }
    
}
