package com.costume.service;

import com.costume.model.Score;
import com.costume.repository.ScoreRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ScoreService {
    @Autowired
    private ScoreRepository scoreRepository;
 
    public List<Score> getAll(){
       return scoreRepository.getAll();
    }
    
    public Optional<Score> getScore(int id){
        return scoreRepository.getScore(id);
    }
    
    public Score save(Score score) {
        if (score.getIdScore() == null) {
            return scoreRepository.save(score);
        } else {
            Optional<Score> scoreUno = scoreRepository.getScore(score.getIdScore());
            if (scoreUno.isEmpty()) {
                return scoreRepository.save(score);
            } else {
                return score;
            }
        }
    }
    
    public Score update(Score score) {
        if (score.getIdScore() != null) {
            Optional<Score> scoreUno = scoreRepository.getScore(score.getIdScore());
            if (!scoreUno.isEmpty()) {
                if(score.getMessageText() != null){
                    scoreUno.get().setMessageText(score.getMessageText());
                }
                
                if(score.getStars() != null && (score.getStars() >= 0 && score.getStars() <=5)){
                    scoreUno.get().setStars(score.getStars());
                }
                return scoreRepository.update(scoreUno.get());
            }
        } 
        return score;
    }
    
    public boolean delete(int id){
        Optional<Score> scoreUno = scoreRepository.getScore(id);
        if (scoreUno.isEmpty()) {
            return false;
        } else {
            scoreRepository.delete(scoreUno.get());
            return true;
        }
    }
}
