package com.costume.service;

import com.costume.model.Reservation;
import com.costume.repository.ReservationRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * Servicio de Reservas
 * @author josva
 */
@Service
public class ReservationService {
    
    /**
     * Variable de reserva de repositorio
     */
    @Autowired
    private ReservationRepository reservationRepository;
 
    /**
     * 
     * @return 
     */
    public List<Reservation> getAll(){
       return reservationRepository.getAll();
    }
    
    /**
     * 
     * @param id
     * @return 
     */
    public Optional<Reservation> getReservation(int id){
        return reservationRepository.getReservation(id);
    }
    
    /**
     * 
     * @param reservation
     * @return 
     */
    public Reservation save(Reservation reservation) {
        if (reservation.getIdReservation() == null) {
            return reservationRepository.save(reservation);
        } else {
            Optional<Reservation> reservationUno = reservationRepository.getReservation(reservation.getIdReservation());
            if (reservationUno.isEmpty()) {
                return reservationRepository.save(reservation);
            } else {
                return reservation;
            }
        }
    }
    
    
    /**
     * 
     * @param reservation
     * @return 
     */
    public Reservation update(Reservation reservation) {
        if (reservation.getIdReservation() != null) {
            Optional<Reservation> reservationUno = reservationRepository.getReservation(reservation.getIdReservation());
            if (!reservationUno.isEmpty()) {
                if(reservation.getStartDate() != null){
                    reservationUno.get().setStartDate(reservation.getStartDate());
                }
                if(reservation.getDevolutionDate() != null){
                    reservationUno.get().setDevolutionDate(reservation.getDevolutionDate());
                }
                if(reservation.getStatus() != null){
                    reservationUno.get().setStatus(reservation.getStatus());
                }
                
                return reservationRepository.update(reservationUno.get());
            }
            return reservation;
        }
        return reservation;
    }
    
    /**
     * 
     * @param id
     * @return 
     */
    public boolean delete(int id){
        Optional<Reservation> reservationUno = reservationRepository.getReservation(id);
        if (reservationUno.isEmpty()) {
            return false;
        } else {
            reservationRepository.delete(reservationUno.get());
            return true;
        }
    }
}
