package com.sergioa.backendMinticReto3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendMinticReto3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
