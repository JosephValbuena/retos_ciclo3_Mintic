package com.sergioa.backendMinticReto3.repository;

import com.sergioa.backendMinticReto3.crud.repository.ReservationRepositoryCrud;
import com.sergioa.backendMinticReto3.model.Reservation;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */
@Repository
public class ReservationRepository {
    @Autowired
    private ReservationRepositoryCrud reservationRepositoryCrud;
    
    public List<Reservation> getAll(){
        return (List<Reservation>) reservationRepositoryCrud.findAll();
    }
    
    public Optional<Reservation> getReservation(int id){
        return reservationRepositoryCrud.findById(id);
    }  
  
    public Reservation save(Reservation reservation){
        return reservationRepositoryCrud.save(reservation);
    }
}
