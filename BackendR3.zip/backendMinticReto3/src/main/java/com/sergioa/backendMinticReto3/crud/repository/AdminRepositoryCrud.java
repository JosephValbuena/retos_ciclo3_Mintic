package com.sergioa.backendMinticReto3.crud.repository;

import com.sergioa.backendMinticReto3.model.Admin;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author josva
 */

public interface AdminRepositoryCrud extends CrudRepository<Admin, Integer>{
    
}
