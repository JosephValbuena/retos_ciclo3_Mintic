package com.sergioa.backendMinticReto3.crud.repository;

import com.sergioa.backendMinticReto3.model.Costume;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author josva
 */

public interface CostumeRepositoryCrud extends CrudRepository<Costume, Integer>{
    
}
