package com.sergioa.backendMinticReto3.services;

import com.sergioa.backendMinticReto3.model.Message;
import com.sergioa.backendMinticReto3.repository.MessageRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author josva
 */

@Service
public class MessageService {
    
    @Autowired
    MessageRepository messageRepository;
    
    public List<Message> getAll(){
        return messageRepository.getAll();
    }
    
    public Message save(Message message){
        if(String.valueOf(message.getId()) == null){
            return messageRepository.save(message);
        }else{
            Optional<Message> unMensaje = messageRepository.getMessage(message.getId());
            if(unMensaje.isEmpty()){
                return messageRepository.save(message);
            }else{
                return message;
            }
        }
    }
    
}
