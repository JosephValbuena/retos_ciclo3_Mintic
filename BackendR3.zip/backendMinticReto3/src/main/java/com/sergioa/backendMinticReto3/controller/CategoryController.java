package com.sergioa.backendMinticReto3.controller;

import com.sergioa.backendMinticReto3.model.Category;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.sergioa.backendMinticReto3.crud.repository.CategoryRepositoryCrud;
import com.sergioa.backendMinticReto3.services.CategoryService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *
 * @author josva
 */
@RequestMapping("/api/Category")
@RestController
@CrossOrigin
public class CategoryController {
    
    @Autowired
    CategoryService categoryService;
    
    @GetMapping("/all")
    public List<Category> getAll(){
        List<Category> categories = (List<Category>) categoryService.getAll();
        return categories;
    }
    
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Category save(@RequestBody Category category){
        return categoryService.save(category);
    }
    
}
