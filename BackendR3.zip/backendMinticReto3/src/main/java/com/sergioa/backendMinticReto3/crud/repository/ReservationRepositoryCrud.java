package com.sergioa.backendMinticReto3.crud.repository;

import com.sergioa.backendMinticReto3.model.Reservation;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author josva
 */
public interface ReservationRepositoryCrud extends CrudRepository<Reservation, Integer>{
    
}
