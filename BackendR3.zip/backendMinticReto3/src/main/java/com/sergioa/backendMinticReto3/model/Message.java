package com.sergioa.backendMinticReto3.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import javax.persistence.*;

/**
 *
 * @author josva
 */

@Entity
@Table(name="message")
public class Message implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
     
    @Column(name="MESSAGETEXT", nullable = false, length = 250)
    private String messagetext;

    @ManyToOne
    @JoinColumn(name="ID_COSTUME",  nullable = false)
    @JsonIgnoreProperties({"messages","reservations"})
    private Costume costume;
    
    
    @ManyToOne
    @JoinColumn(name="ID_CLIENT",  nullable = false)
    @JsonIgnoreProperties({"messages","reservations"})
    private Client client;
 
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMessagetext() {
        return messagetext;
    }

    public void setMessagetext(String messagetext) {
        this.messagetext = messagetext;
    }

    public Costume getCostume() {
        return costume;
    }

    public void setCostume(Costume costume) {
        this.costume = costume;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
    
    
    
    
}
