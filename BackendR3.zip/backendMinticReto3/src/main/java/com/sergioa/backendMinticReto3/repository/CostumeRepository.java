/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sergioa.backendMinticReto3.repository;

import com.sergioa.backendMinticReto3.crud.repository.CostumeRepositoryCrud;
import com.sergioa.backendMinticReto3.model.Costume;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */

@Repository
public class CostumeRepository {
    
    @Autowired
    CostumeRepositoryCrud costumeRepositoryCrud;
    
    public List<Costume> getAll(){
        return (List<Costume>) costumeRepositoryCrud.findAll();
    }
    
    public Optional<Costume> getCostume(int id){
        return costumeRepositoryCrud.findById(id);
    }
    
    public Costume save(Costume costume){
        return costumeRepositoryCrud.save(costume);
    }
}
