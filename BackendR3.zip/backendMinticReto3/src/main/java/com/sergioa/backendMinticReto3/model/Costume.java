package com.sergioa.backendMinticReto3.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

/**
 *
 * @author josva
 */

@Entity
@Table(name="costume")
public class Costume {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    @Column(name="NAME", nullable = false, length = 45)
    private String name;
    
    @Column(name="BRAND", nullable = false, length = 45)
    private String brand;
    
    @Column(name= "YEAR", nullable = false)
    private int year;
    
    @Column(name="DESCRIPTION", nullable = false, columnDefinition = "Text")
    private String description;
    
    @ManyToOne
    @JoinColumn(name="CATEGORY_ID", nullable = false)
    @JsonIgnoreProperties("costumes")
    public Category category_id;

    @OneToMany(cascade={CascadeType.PERSIST},mappedBy="costume")
    @JsonIgnoreProperties({"costume", "client"})
    public List<Message> messages;
    
    @OneToMany(cascade={CascadeType.PERSIST}, mappedBy="costume")
    @JsonIgnoreProperties({"id_costume","id_client"})
    public List<Reservation> reservations;

    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(List<Reservation> reservations) {
        this.reservations = reservations;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Category getCategory_id() {
        return category_id;
    }

    public void setCategory_id(Category category_id) {
        this.category_id = category_id;
    }
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
    
}
