package com.sergioa.backendMinticReto3.crud.repository;

import com.sergioa.backendMinticReto3.model.Category;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author josva
 */

public interface CategoryRepositoryCrud extends CrudRepository<Category, Integer>{
    
}
