package com.sergioa.backendMinticReto3.controller;

import com.sergioa.backendMinticReto3.model.Admin;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.sergioa.backendMinticReto3.services.AdminService;
import org.springframework.http.HttpStatus;

/**
 * Controlador de Administradores
 * @author josva
 */
@RestController
@RequestMapping("/api/Admin")
@CrossOrigin
public class AdminController {
    
    @Autowired
    private AdminService adminService;
    
    @GetMapping("/all")
    public List<Admin> getAll(){
        return adminService.getAll();
    }
    
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Admin save(@RequestBody Admin admin){
        return adminService.save(admin);
    }
}
