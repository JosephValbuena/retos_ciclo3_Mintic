package com.costume.service;

import com.costume.model.Client;
import com.costume.repository.ClientRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService {

    @Autowired
    private ClientRepository clientRepository;

    public List<Client> getAll() {
        return clientRepository.getAll();
    }
    
    public Optional<Client> getClient(int id){
        return clientRepository.getClient(id);
    }

    public Client save(Client client) {
        if (client.getIdClient() == null) {
            return clientRepository.save(client);
        } else {
            Optional<Client> unCliente = clientRepository.getClient(client.getIdClient());

            if (unCliente.isEmpty()) {
                return clientRepository.save(client);
            } else {
                return client;
            }
        }
    }
    
    public Client update(Client client){
        if(client.getIdClient() != null){
            Optional<Client> unCliente = clientRepository.getClient(client.getIdClient());
            
            if(!unCliente.isEmpty()){
                if(client.getEmail() != null){
                    unCliente.get().setEmail(client.getEmail());
                }
                if(client.getPassword() != null){
                    unCliente.get().setPassword(client.getPassword());
                }
                
                if(client.getName() != null){
                    unCliente.get().setName(client.getName());
                }
                
                if(client.getAge() != null){
                    unCliente.get().setAge(client.getAge());
                }
                
                return clientRepository.update(unCliente.get());
            }
        }
        return client;
    }
    
    public boolean delete(int id){
        
        Optional<Client> unCliente = clientRepository.getClient(id);
            
        if(unCliente.isEmpty()){
            return false;
        }else{
            clientRepository.delete(unCliente.get());
            return true;
        }
    }
}
