package com.costume.service;

import com.costume.model.Category;
import com.costume.repository.CategoryRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public List<Category> getAll() {
        return categoryRepository.getAll();
    }

    public Category save(Category category) {
        if (category.getId() == null) {
            return categoryRepository.save(category);
        } else {
            Optional<Category> category1 = categoryRepository.getCategory(category.getId());
            if (category1.isEmpty()) {
                return categoryRepository.save(category);
            } else {
                return category;
            }
        }
    }
    
    public Optional<Category> getCategory(int categoryId){
        return categoryRepository.getCategory(categoryId);
    }
    
    public Category update(Category category){
        if (category.getId() != null) {
            Optional<Category> category1 = categoryRepository.getCategory(category.getId());
            if (!category1.isEmpty()) {
                if(category.getDescription() != null){
                    category1.get().setDescription(category.getDescription());
                }
                
                if(category.getName() != null){
                    category1.get().setName(category.getName());
                } 
                
                return categoryRepository.update(category1.get());
            }
        } 
        return category;
    }
    
    public Boolean delete(int id){
        Optional<Category> category1 = categoryRepository.getCategory(id);
        if (category1.isEmpty()) {
            return false;
        } else {
            categoryRepository.delete(category1.get());
            return true;
        }
    }
}
